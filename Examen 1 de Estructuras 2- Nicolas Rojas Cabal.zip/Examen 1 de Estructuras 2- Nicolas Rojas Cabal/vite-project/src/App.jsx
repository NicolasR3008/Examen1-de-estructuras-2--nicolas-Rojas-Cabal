//Nicolas Rojas cabal- 2226088
import React, { useState } from "react";
import "./App.css";

function App() {
  const [imagenes, setImagenes] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [contadorNombre, setContadorNombre] = useState(1);

  const agregarImagen = () => {
    const nombre = `foto${contadorNombre}`;
    const url = `https://picsum.photos/id/${contadorNombre}/300/200`;

    const nuevaImagen = {
      id: contadorNombre, 
      nombre,
      url,
    };

    setImagenes([...imagenes, nuevaImagen]);
    setContadorNombre(contadorNombre + 1);
  };

  const imagenesFiltradas = imagenes.filter((imagen) =>
    imagen.nombre.toLowerCase().includes(busqueda.toLowerCase())
  );

  return (
    <div className="App">
      <button className="agregarImagen" onClick={agregarImagen}>
        Agregar Imagen
      </button>

      <input
        type="text"
        placeholder="nombre de la imagen (todas siguen la estructura de foto(n)"
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
        className="buscar-input"
      />

      <div className="imagenes-lista">
        {imagenesFiltradas.map((imagen) => (
          <div key={imagen.id} className="imagen-item">
            <img src={imagen.url} alt={imagen.nombre} />
            <p>{imagen.nombre}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;